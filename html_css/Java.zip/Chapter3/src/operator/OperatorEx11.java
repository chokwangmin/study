package operator;

public class OperatorEx11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int bNum1 = 0B00001010; //10
		int bNum2 = 0B00000101; // 5
		System.out.println(bNum1 & bNum2);
		System.out.println(bNum1 | bNum2);
	}

}
