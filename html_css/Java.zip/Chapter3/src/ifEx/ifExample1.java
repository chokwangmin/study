package ifEx;

public class ifExample1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		char gender = 'm';
		if(gender == 'f') {
			System.out.println("�����Դϴ�");
			else( 1 == 1)
		else
			System.out.println("�����Դϴ�");
		}
		
		int age = 10;
		int charge = 0'
		if(age < 8 ) {
		
		}
		else if (age < 14) {
			
		}
	}

}
