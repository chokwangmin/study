package varialble;

public class CharTest {

	public static void main(String[] args) {
		
		char ch = 'A';
		System.out.println(ch);
		System.out.println((int)ch);
		
		int ich = 66;
		System.out.println(ich);
		System.out.println((char)ich);
		
		char hangul ='\uAC01';
		System.out.println(hangul);
		
	}

}
