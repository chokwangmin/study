package varialble;

public class BinaryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num = 10;		//10����
		int bNum = 0B1010; // 2����
		int oNum = 012; //8����
		int xNum = 0XA; //16����
		System.out.println(num);
		System.out.println(bNum);
		System.out.println(oNum);
		System.out.println(xNum);
	}

}
