package varialble;

public class implicitConversion {

	public static void main(String[] args) {
		// �ڵ�����ȯ (������ ����ȯ

		byte bNum = 10;
		int iNum = bNum;
		
		System.out.println(bNum);
		System.out.println(iNum);
		
		int iNum2 = 20;
		float fNum = iNum2;
		System.out.println(fiNum2);
	}

}
