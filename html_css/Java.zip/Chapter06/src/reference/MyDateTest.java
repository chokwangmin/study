package reference;

public class MyDateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyDate date = new MyDate();
		
		Date.setday = 10;
		Date.setMonth = 13;
		Date.setYear = 2022;
		
		Date.showMyDate();
		

	}

}
